package org.example.crud.Service;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import org.example.crud.Model.PostionModel;
import org.example.crud.Repository.PostionModelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@Service
public class PostionModelService {

    private final PostionModelRepository postionModelRepository;

    @Autowired
    public PostionModelService(PostionModelRepository postionModelRepository) {
        this.postionModelRepository = postionModelRepository;
    }

    // display data



    public List<PostionModel> processCsvFile(MultipartFile file) throws IOException, CsvValidationException {
        List<PostionModel> postionModels = new ArrayList<>();

        try (InputStream inputStream = file.getInputStream()) {
            // Use Apache Commons CSV to handle CSV files
            try (CSVReader csvReader = new CSVReader(new InputStreamReader(inputStream))) {
                String[] headers = csvReader.readNext(); // Assuming the first row contains headers

                String[] nextRecord;
                while ((nextRecord = csvReader.readNext()) != null) {
                    PostionModel postionModel = new PostionModel();
                    postionModel.setChapitre(nextRecord[0]);
                    postionModel.setLibelle_chapitre(nextRecord[1]);
                    postionModel.setDevise(nextRecord[2]);
                    postionModel.setAgence(nextRecord[3]);
                    postionModel.setCompte(nextRecord[4]);
                    postionModel.setIntitule(nextRecord[5]);
                    postionModel.setCode_client(nextRecord[6]);
                    postionModel.setNome_client(nextRecord[7]);
                    postionModel.setCompte_ferme(nextRecord[8]);
                    postionModel.setSolde_debit(nextRecord[9]);
                    postionModel.setSolde_credit(nextRecord[10]);
                    postionModel.setSld_devise(nextRecord[11]);
                    postionModel.setContre_value_mru_debit(nextRecord[12]);
                    postionModel.setContre_value_mru_credit(nextRecord[13]);

                    // Add mappings for additional fields as needed

                    postionModels.add(postionModel);
                }
            }
        }

        return postionModels;
    }

    public void saveAll(List<PostionModel> postionModels) {
        postionModelRepository.saveAll(postionModels);
    }

    public List<PostionModel> getAllPostionModels() {
        return postionModelRepository.findAll();



}}
