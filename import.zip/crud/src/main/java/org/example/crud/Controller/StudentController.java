package org.example.crud.Controller;

import org.example.crud.Model.Student;
import org.example.crud.Repository.StudentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/trading")
@CrossOrigin(origins = "*")
public class StudentController {


//    private final Repository.StudentRepository StudentRepository;
    private   StudentRepository studentRepository;




    // Create a new student
    @PostMapping("/student")
//    public student createStudent(@RequestBody student student) {
//        return Repository.StudentRepository.save(student);
       public Student saveStudent(@RequestBody Student student){
        return  studentRepository.save(student);
}


    // Get all students
    @GetMapping("/Students")
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // Get a specific student by ID
    @GetMapping("/{id}")
    public Optional<Student> getStudentById(@PathVariable Long id) {
        return studentRepository.findById(id);
    }

    // Update a student
    @PutMapping("/{id}")
    public Student updateStudent(@PathVariable Long id, @RequestBody Student updatedStudent) {
        // Check if the student with the given ID exists
        if (studentRepository.existsById(id)) {
            updatedStudent.setStudent_ID(id);
            return studentRepository.save(updatedStudent);
        } else {
            // Handle not found scenario, you may choose to throw an exception or return an appropriate response
            return null;
        }
    }

    // Delete a student by ID
    @DeleteMapping("/{id}")
    public void deleteStudent(@PathVariable Long id) {
        studentRepository.deleteById(id);
    }
}
