package org.example.crud.Controller;

import org.example.crud.Model.PostionModel;
import org.example.crud.Service.PostionModelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/trading")
public class PostionModelController {

    private final PostionModelService postionModelService;

    @Autowired
    public PostionModelController(PostionModelService postionModelService) {
        this.postionModelService = postionModelService;
    }
    @GetMapping("/upload")
    public ResponseEntity<List<PostionModel>> getAllPostionModels() {
        List<PostionModel> postionModels = postionModelService.getAllPostionModels();
        return ResponseEntity.ok(postionModels);}

    @PostMapping(path = "/postion_model", consumes = "multipart/form-data")
    public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
        try {
            String fileName = file.getOriginalFilename();
            List<PostionModel> postionModels;

            if (fileName != null && fileName.endsWith(".xlsx")) {
                // Process Excel file
                postionModels = postionModelService.processCsvFile(file);
            } else if (fileName != null && fileName.endsWith(".csv")) {
                // Process CSV file
                postionModels = postionModelService.processCsvFile(file);
            } else {
                return ResponseEntity.badRequest().body("Invalid file format. Please upload an Excel (.xlsx) or CSV (.csv) file.");
            }

            postionModelService.saveAll(postionModels);
            return ResponseEntity.ok("File uploaded successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body("Internal server error");
        }
    }

}
