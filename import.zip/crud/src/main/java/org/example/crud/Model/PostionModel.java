package org.example.crud.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class PostionModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private  long id ;
    private String chapitre;
    private String libelle_chapitre;
    private String  devise;
    private String  agence;
    private String  compte;
    private String intitule;
    private String  code_client;
    private String  nome_client;
    private String  compte_ferme;
    private String   solde_debit;
    private String solde_credit;
    private String  sld_devise;
    private String contre_value_mru_debit;
    private String contre_value_mru_credit;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getChapitre() {
        return chapitre;
    }

    public void setChapitre(String chapitre) {
        this.chapitre = chapitre;
    }

    public String getLibelle_chapitre() {
        return libelle_chapitre;
    }

    public void setLibelle_chapitre(String libelle_chapitre) {
        this.libelle_chapitre = libelle_chapitre;
    }

    public String getDevise() {
        return devise;
    }

    public void setDevise(String devise) {
        this.devise = devise;
    }

    public String getAgence() {
        return agence;
    }

    public void setAgence(String agence) {
        this.agence = agence;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public String getCode_client() {
        return code_client;
    }

    public void setCode_client(String code_client) {
        this.code_client = code_client;
    }

    public String getNome_client() {
        return nome_client;
    }

    public void setNome_client(String nome_client) {
        this.nome_client = nome_client;
    }

    public String getCompte_ferme() {
        return compte_ferme;
    }

    public void setCompte_ferme(String compte_ferme) {
        this.compte_ferme = compte_ferme;
    }

    public String getSolde_debit() {
        return solde_debit;
    }

    public void setSolde_debit(String solde_debit) {
        this.solde_debit = solde_debit;
    }

    public String getSolde_credit() {
        return solde_credit;
    }

    public void setSolde_credit(String solde_credit) {
        this.solde_credit = solde_credit;
    }

    public String getSld_devise() {
        return sld_devise;
    }

    public void setSld_devise(String sld_devise) {
        this.sld_devise = sld_devise;
    }

    public String getContre_value_mru_debit() {
        return contre_value_mru_debit;
    }

    public void setContre_value_mru_debit(String contre_value_mru_debit) {
        this.contre_value_mru_debit = contre_value_mru_debit;
    }

    public String getContre_value_mru_credit() {
        return contre_value_mru_credit;
    }

    public void setContre_value_mru_credit(String contre_value_mru_credit) {
        this.contre_value_mru_credit = contre_value_mru_credit;
    }
}



