package org.example.crud.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.example.crud.Model.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
    // You can add custom query methods here if needed
}