package org.example.crud.Repository;


import org.example.crud.Model.PostionModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostionModelRepository extends JpaRepository<PostionModel, Long> {
    // You can add custom query methods if needed
}
